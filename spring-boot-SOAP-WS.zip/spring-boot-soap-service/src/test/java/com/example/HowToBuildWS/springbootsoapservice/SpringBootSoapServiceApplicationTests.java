package com.example.HowToBuildWS.springbootsoapservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
