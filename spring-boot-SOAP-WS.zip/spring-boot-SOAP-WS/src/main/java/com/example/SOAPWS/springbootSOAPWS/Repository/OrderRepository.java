package com.example.SOAPWS.springbootSOAPWS.Repository;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import https.www_patelsoap101_com.xml.orderstatus.OrderStatus;

@Component
public class OrderRepository {
	
	private static final Map<String,OrderStatus> orderInfo = new HashMap<>();
	
	@PostConstruct
	public void initData() {
		
		OrderStatus order = new OrderStatus();
		order.setOrderId("10001");
		order.setStatus("In Progress");
		order.setSubStatus("Order being handled manually");
		orderInfo.put(order.getOrderId(), order);
	}
	
	public OrderStatus findOrder(String order) {
		Assert.notNull(order, "The order number must not be null");
		return orderInfo.get(order);
	}
}
