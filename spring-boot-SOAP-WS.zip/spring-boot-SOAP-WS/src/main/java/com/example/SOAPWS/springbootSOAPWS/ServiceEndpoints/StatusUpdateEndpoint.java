package com.example.SOAPWS.springbootSOAPWS.ServiceEndpoints;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.example.SOAPWS.springbootSOAPWS.Repository.OrderRepository;

import https.www_patelsoap101_com.xml.orderstatus.OrderStatusRequest;
import https.www_patelsoap101_com.xml.orderstatus.OrderStatusResponse;

@Endpoint
public class StatusUpdateEndpoint {
	
	
	public static final String NAMESPACE_URI = "https://www.patelsoap101.com/xml/orderstatus";
	
	private OrderRepository orderRepo;
	
	@Autowired
	public StatusUpdateEndpoint(OrderRepository orderRepo) {
		this.orderRepo=orderRepo;
	}

	@PayloadRoot(namespace =NAMESPACE_URI, localPart = "OrderStatusRequest")
	@ResponsePayload
	public OrderStatusResponse getStatus(@RequestPayload OrderStatusRequest request) {
		
		OrderStatusResponse response = new OrderStatusResponse();
		response.setOrderStatus(orderRepo.findOrder(request.getOrder()));
		return response;
	}
	
}
