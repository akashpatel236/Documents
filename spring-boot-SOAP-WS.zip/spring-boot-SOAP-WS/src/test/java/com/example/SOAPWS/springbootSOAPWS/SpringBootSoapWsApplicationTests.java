package com.example.SOAPWS.springbootSOAPWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
