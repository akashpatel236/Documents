package com.client.emtn.EMTNClientAP.InvokeService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.client.emtn.EMTNClientAP.Model.IncomingOrderDTO;

public class TIEService {
	
	
	public static void callService(){
	RestTemplate template = new RestTemplate();
	String result = template.getForObject("http://localhost:8090/orderInfo/fetch",String.class);

	System.out.println(result);
	
	ResponseEntity<List<IncomingOrderDTO>> response = template.exchange(
			  "http://localhost:8090/orderInfo/fetch",
			  HttpMethod.GET,
			  null,
			  new ParameterizedTypeReference<List<IncomingOrderDTO>>(){});
	
	List<IncomingOrderDTO> data = response.getBody();
	Iterator<IncomingOrderDTO> it=data.iterator();
	
	for (IncomingOrderDTO incomingOrderDTO : data) {
		
		System.out.println(incomingOrderDTO.getPostalCode()+incomingOrderDTO.getHousenumber());
	}
	
	}
}
