package com.client.emtn.EMTNClientAP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.client.emtn.EMTNClientAP.InvokeService.TIEService;

@SpringBootApplication
public class EmtnClientApApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmtnClientApApplication.class, args);
		
		TIEService.callService();
	}

}
