package com.client.emtn.EMTNClientAP.Model;

public class IncomingOrderDTO {
	
	private int orderid;
	private String postalCode="";
	private String housenumber="";
	private String mediaType="";
	private String capacity="";
	

	public IncomingOrderDTO(){
		
	}
	
	
	public IncomingOrderDTO(int orderid,String postalCode, String housenumber, String mediaType, String capacity) {
		super();
		this.orderid=orderid;
		this.postalCode = postalCode;
		this.housenumber = housenumber;
		this.mediaType = mediaType;
		this.capacity = capacity;
	}



	public int getOrderid() {
		return orderid;
	}


	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}


	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getHousenumber() {
		return housenumber;
	}
	public void setHousenumber(String housenumber) {
		this.housenumber = housenumber;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	

	
}
