package com.tie.emtn.starter.EMTNBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmtnBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmtnBootApplication.class, args);
	}

}
