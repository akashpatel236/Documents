package com.tie.emtn.starter.EMTNBoot.Commons;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class Utility {


	private static final Logger log = LogManager.getLogger(Utility.class);
	
public static Connection getConnection() throws Exception{
		
		Connection conn=null;
		
		//System.out.println("Connecting to Oracle (JNDI), datasource:" +"jdbc/tie/OomDB");
		log.debug("Connecting to Oracle (JNDI), datasource:" +"jdbc/tie/OomDB");
		
		try{
			
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("jdbc/tie/OomDB");
			
			conn=ds.getConnection();
			log.info("Connected to Oracle (JNDI).");
		}catch(Exception e){
			log.error("Error while setting up connection :"+e.getMessage());
		}
		
		return conn;
		
	}
	
}
