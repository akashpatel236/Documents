package com.tie.emtn.starter.EMTNBoot.ResponseModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.tie.emtn.starter.EMTNBoot.Commons.Utility;


@Repository("responseDAO")
public class AuraportalFrontChannelDAO {
	
	private static ArrayList<IncomingOrderDTO> ordersList = new ArrayList<IncomingOrderDTO>();
	
	private static final Logger log = LogManager.getLogger(AuraportalFrontChannelDAO.class);
	
	static{
		
		ordersList.add(new IncomingOrderDTO(2, "Vendor", "WES",new ServiceInfo("21", "WOS024543", "230V AC"), 
				new SiteInfo("2516CK", "3", "TP8"),new Result("Accepted", "Your prequal is ready to order","Netherlands")));
		
	}
	
	public static ArrayList<IncomingOrderDTO> getOrdersList() {
		return ordersList;
	}

	public static void setOrdersList(ArrayList<IncomingOrderDTO> order) {
		ordersList.addAll(order);
	}
	
	
	public int upadatePrequalInformationToDB(IncomingOrderDTO incomingdata) throws Exception{
		
		Connection conn=null;
		PreparedStatement ps=null;
		int count=0;
		
		String sql="update PREQUAL_API_DATA set stauts=?,description=?,region=? where sitenumber=?";
		log.debug("Executing query :"+sql);
		
			conn=Utility.getConnection();
			
			if(conn!=null) {
			ps=conn.prepareStatement(sql);
		
			ps.setString(1,incomingdata.getResult().getStatus());
			ps.setString(2,incomingdata.getResult().getDescription());
			ps.setString(3,incomingdata.getResult().getPrequalRegion());
			ps.setString(4,incomingdata.getServiceInfo().getSiteNumber());
			
			count=ps.executeUpdate();
			log.debug("Update executed sucessfully.");
		}
		return count;
		
	}

}
