package com.tie.emtn.starter.EMTNBoot.PrequalResponseController;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tie.emtn.starter.EMTNBoot.ResponseModel.AuraportalFrontChannelDAO;
import com.tie.emtn.starter.EMTNBoot.ResponseModel.IncomingOrderDTO;
import com.tie.emtn.starter.EMTNBoot.ResponseModel.Result;
import com.tie.emtn.starter.EMTNBoot.ResponseModel.ServiceInfo;
import com.tie.emtn.starter.EMTNBoot.ResponseModel.SiteInfo;

@RestController
@RequestMapping(path="/auraportal")
public class AuraportalFrontChannel {
	
	@Autowired
	private AuraportalFrontChannelDAO prequallist;
	
	private static final Logger log = LogManager.getLogger(AuraportalFrontChannel.class);
	
	@PostMapping(path="/prequalResponse",produces="application/json")
	public ResponseEntity<String> prequalUpdate(@RequestBody IncomingOrderDTO incomingdata){
	
		int count=0;
		
		//Add order to the list
		prequallist.setOrdersList(addOrderToList(incomingdata));
		log.info("Order list added "+incomingdata.getServiceInfo().getEuaSiteAccess());
		
		try {
			count=prequallist.upadatePrequalInformationToDB(incomingdata);
		} catch (Exception e) {
			log.error("Exception occur while executing query:"+e.getMessage());

		}
		log.info("Database ROW affected :"+count);
		
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	public ArrayList<IncomingOrderDTO> addOrderToList(IncomingOrderDTO incomingdata) {
		
		ArrayList<IncomingOrderDTO> newOrder= new ArrayList<>(); 
		
		Integer id =prequallist.getOrdersList().size()+1;
		 
		newOrder.add(new
				 IncomingOrderDTO(id,incomingdata.getOriginiator(),incomingdata.getReceiver(),
						 
						 new ServiceInfo(incomingdata.getServiceInfo().getSiteNumber(),
								 incomingdata.getServiceInfo().getEuaSiteAccess(),
								 incomingdata.getServiceInfo().getPowerSupply()),
						 
						 new SiteInfo(incomingdata.getSiteInfo().getPostalCode(),
						 			incomingdata.getSiteInfo().getHouseNumber(),
						 			incomingdata.getSiteInfo().getHouseNumberExtenstion()),
						 new Result(incomingdata.getResult().getStatus(), 
								 	incomingdata.getResult().getDescription(), 
								 	incomingdata.getResult().getPrequalRegion())
						 ));
		 
		
		log.info("Order list added "+incomingdata.getServiceInfo().getEuaSiteAccess());
		
		return newOrder;
	}
	
	
	@GetMapping(path="/fetch",produces="application/json")
	public ArrayList<IncomingOrderDTO> getInfo(){
		
		log.info("GET method invoke by Auraportal channel");
		return prequallist.getOrdersList();
	}

	

}
