package com.tie.emtn.starter.EMTNBoot.RequestModel;

public class ServiceInfo {
	
	private String siteNumber;
	private String euaSiteAccess;
	private String powerSupply;
	
	
	
	public ServiceInfo(String siteNumber, String euaSiteAccess, String powerSupply) {
		super();
		this.siteNumber = siteNumber;
		this.euaSiteAccess = euaSiteAccess;
		this.powerSupply = powerSupply;
	}
	
	public String getSiteNumber() {
		return siteNumber;
	}
	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}
	public String getEuaSiteAccess() {
		return euaSiteAccess;
	}
	public void setEuaSiteAccess(String euaSiteAccess) {
		this.euaSiteAccess = euaSiteAccess;
	}
	public String getPowerSupply() {
		return powerSupply;
	}
	public void setPowerSupply(String powerSupply) {
		this.powerSupply = powerSupply;
	}
	
	

}
