package com.tie.emtn.starter.EMTNBoot.RequestModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.tie.emtn.starter.EMTNBoot.Commons.Utility;

@Repository("requestDAO")
public class IncomingChannelDAO {
	
	private static ArrayList<IncomingOrderDTO> ordersList = new ArrayList<IncomingOrderDTO>();
	
	private static final Logger log = LogManager.getLogger(IncomingChannelDAO.class);
	
	static{
		
		ordersList.add(new IncomingOrderDTO(1, "Vendor", "WES",new ServiceInfo("20", "WOS0222123", "48V DC"), 
				new SiteInfo("2275VN", "36", "A")));

		ordersList.add(new IncomingOrderDTO(2, "Vendor", "WES",new ServiceInfo("21", "WOS024543", "230V AC"), 
				new SiteInfo("2516CK", "3", "TP8")));
	}
	
	public static ArrayList<IncomingOrderDTO> getOrdersList() {
		return ordersList;
	}

	public static void setOrdersList(ArrayList<IncomingOrderDTO> order) {
		ordersList.addAll(order);
	}

	public int storePrequalInformationToDB(IncomingOrderDTO incomingdata) throws Exception{
	
		Connection conn=null;
		PreparedStatement ps=null;
		int count=0;
		
		String sql="insert into PREQUAL_API_DATA (orderid,SiteAccessID,PowerSupply,SiteNumber,HouseNumber,PostalCode) "
				+ " values (?,?,?,?,?,?)";
		log.debug("Executing query :"+sql);
		
			conn=Utility.getConnection();
			ps=conn.prepareStatement(sql);
		
			if(conn!=null) {
				ps.setInt(1,incomingdata.getOrderid());
				ps.setString(2,incomingdata.getServiceInfo().getEuaSiteAccess());
				ps.setString(3,incomingdata.getServiceInfo().getPowerSupply());
				ps.setString(4,incomingdata.getServiceInfo().getSiteNumber());
				ps.setString(5,incomingdata.getSiteInfo().getHouseNumber());
				ps.setString(6,incomingdata.getSiteInfo().getPostalCode());
				
				count=ps.executeUpdate();
				log.debug("Update executed sucessfully.");
			}
		return count;
		
	}
	

}



