package com.tie.emtn.starter.EMTNBoot.PrequalRequestController;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tie.emtn.starter.EMTNBoot.RequestModel.*;


@RestController
@RequestMapping(path="/vendor")
public class IncomingProcessingChannel {
	
	@Autowired
	private IncomingChannelDAO orderlist;
	
	private static final Logger log = LogManager.getLogger(IncomingProcessingChannel.class);

	//@PostMapping(path="/",consumes="application/json", produces="application/json")
	@PostMapping(path="/invokePrequalOrder",produces="application/json")
	public ResponseEntity<String> addOrderDetails(@RequestBody IncomingOrderDTO incomingdata){
		
		log.info("Post method invoked..!!");
		int count=0;
		//Validate Order & perform operations
		
		//Add order to the list
		orderlist.setOrdersList(addOrderToList(incomingdata));
		
		try {
			 count=orderlist.storePrequalInformationToDB(incomingdata);
		} catch (Exception e) {
			log.error("Exception occur while executing query:"+e.getMessage());
		}
		log.debug("Database ROW affected :"+count);
		/*URI location= ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(incomingdata.getOrderid()).toUri();
				
		return ResponseEntity.created(location).build();*/
		return new ResponseEntity(HttpStatus.ACCEPTED);
	}
	
	
	public ArrayList<IncomingOrderDTO> addOrderToList(IncomingOrderDTO incomingdata) {
		
		ArrayList<IncomingOrderDTO> newOrder= new ArrayList<>(); 
		
		Integer id =orderlist.getOrdersList().size()+1;
		incomingdata.setOrderid(id);
		newOrder.add(new
				 IncomingOrderDTO(id,incomingdata.getOriginiator(),incomingdata.getReceiver(),
						 
						 new ServiceInfo(incomingdata.getServiceInfo().getSiteNumber(),
								 incomingdata.getServiceInfo().getEuaSiteAccess(),
								 incomingdata.getServiceInfo().getPowerSupply()),
						 
						 new SiteInfo(incomingdata.getSiteInfo().getPostalCode(),
						 			incomingdata.getSiteInfo().getHouseNumber(),
						 			incomingdata.getSiteInfo().getHouseNumberExtenstion())));
		 
		
		log.info("Order list added "+incomingdata.getServiceInfo().getEuaSiteAccess());
		
		return newOrder;
	}
	
	
	@GetMapping(path="/fetch",produces="application/json")
	public ArrayList<IncomingOrderDTO> getInfo(){
	
		log.info("GET method invoke by Vendor");
		System.out.println("Jackson API usage : ");
		IncomingOrderDTO orderDTO = new IncomingOrderDTO(1, "Vendor", "WES",new ServiceInfo("20", "WOS0222123", "48V DC"), 
				new SiteInfo("2275VN", "36", "A")); 
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonData="";
		try {
			jsonData = mapper.writeValueAsString(orderDTO);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			System.out.println();
		}
		System.out.println("JSON is :"+jsonData);
		return orderlist.getOrdersList();
	}

}







