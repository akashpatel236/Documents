package com.tie.emtn.starter.EMTNBoot.ResponseModel;

public class SiteInfo {

	
	private String postalCode;
	private String houseNumber;
	private String houseNumberExtenstion;
	
	
	
	public SiteInfo(String postalCode, String houseNumber, String houseNumberExtenstion) {
		super();
		this.postalCode = postalCode;
		this.houseNumber = houseNumber;
		this.houseNumberExtenstion = houseNumberExtenstion;
	}
	
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getHouseNumberExtenstion() {
		return houseNumberExtenstion;
	}
	public void setHouseNumberExtenstion(String houseNumberExtenstion) {
		this.houseNumberExtenstion = houseNumberExtenstion;
	}
	
	
}
