package com.tie.emtn.starter.EMTNBoot.RequestModel;

public class IncomingOrderDTO {

	private int orderid;
	private String originiator;
	private String receiver;
	private ServiceInfo serviceInfo;
	private SiteInfo siteInfo;
	
	public IncomingOrderDTO(){
		
	}

	
	
	public IncomingOrderDTO(int orderid, String originiator, String receiver, ServiceInfo serviceInfo,
			SiteInfo siteInfo) {
		super();
		this.orderid = orderid;
		this.originiator = originiator;
		this.receiver = receiver;
		this.serviceInfo = serviceInfo;
		this.siteInfo = siteInfo;
	}



	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getOriginiator() {
		return originiator;
	}

	public void setOriginiator(String originiator) {
		this.originiator = originiator;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public ServiceInfo getServiceInfo() {
		return serviceInfo;
	}

	public void setServiceInfo(ServiceInfo serviceInfo) {
		this.serviceInfo = serviceInfo;
	}

	public SiteInfo getSiteInfo() {
		return siteInfo;
	}

	public void setSiteInfo(SiteInfo siteInfo) {
		this.siteInfo = siteInfo;
	}
	
	

	
}
