package com.tie.emtn.starter.EMTNBoot.ResponseModel;

public class IncomingOrderDTO {

	private int orderid;
	private String originiator;
	private String receiver;
	private ServiceInfo serviceInfo;
	private SiteInfo siteInfo;
	private Result result;
	
	public IncomingOrderDTO(){
		
	}

	
	
	public IncomingOrderDTO(int orderid, String originiator, String receiver, ServiceInfo serviceInfo,
			SiteInfo siteInfo,Result result) {
		super();
		this.orderid = orderid;
		this.originiator = originiator;
		this.receiver = receiver;
		this.serviceInfo = serviceInfo;
		this.siteInfo = siteInfo;
		this.result=result;
	}



	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getOriginiator() {
		return originiator;
	}

	public void setOriginiator(String originiator) {
		this.originiator = originiator;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public ServiceInfo getServiceInfo() {
		return serviceInfo;
	}

	public void setServiceInfo(ServiceInfo serviceInfo) {
		this.serviceInfo = serviceInfo;
	}

	public SiteInfo getSiteInfo() {
		return siteInfo;
	}

	public void setSiteInfo(SiteInfo siteInfo) {
		this.siteInfo = siteInfo;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}
	
	

	
}
