package com.test.form;

import org.apache.struts.action.ActionForm;

public class HelloWorldForm extends ActionForm {

	private static final long serialVersionUID = -473562596852452021L;
	
	private String username;
	private String password;
	
	private String value1;

	

	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
