package com.test.action;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.sql.*;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.test.form.HelloWorldForm;

public class HelloWorldAction extends Action {

@Override
public ActionForward execute(ActionMapping mapping, ActionForm form,
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {
	
		Connection con=null;
		HelloWorldForm hwForm = (HelloWorldForm) form;

		
			hwForm.setUsername("akashpatel");
			hwForm.setPassword("*******");
			
		
			String result = "iojsdfgs|o9df^u7389rurnw$8er7|h9weu"+'\n'+"Akash Patel"+"\n"
					+"1/1 enabked up  asksdfjdfijdfofj"
					+"sdfkjsdfijdfijdf"+"\n"+
					"sfldjfjdfgijfgiofjgoij"
					+"sdfkjsdfijdfijdf"+"\n"+
					"sfldjfjdfgijfgiofjgoij"
					+"sdfkjsdfijdfijdf"+"\n"+
					"sfldjfjdfgijfgiofjgoij"
					+"1/1 dsfkjdfkg up sfldjfkdf dfkugndfkg"+
					"1/2 esdfkjdngd kdfgnkfjgkfg kjjdgfjg"
					+"1/11 dsfkjdfkg up sfldjfkdf dfkugndfkg"+
					"1/12 esdfkjdngd kdfgnkfjgkfg kjjdgfjg";
			
			 result.replaceAll("(\r\n|\r|\n|\n\r)", "<br/>");
			
			hwForm.setValue1(result.replaceAll("(\r\n|\r|\n|\n\r)", "<br/>"));
			
			System.out.println(result);
			
			return mapping.findForward("success");
			
	}

}


