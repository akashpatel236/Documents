package com.test;

public class TestString {
	
	
	
	private String formatString(String inputString, boolean replaceSpaces) {

	    String outputString = new String("");
	    char c;

	    // remove tabs by replacing them by spaces
	    inputString = inputString.replace('\t', ' ');

	    // replace carriage return & linefeed by the HTML break <BR>
	    // when replaceSpaces is true spaces are replaced by a HTML none breakable space: &nbsp;
	    for (int i = 0; i < inputString.length(); i++) {
	      c = inputString.charAt(i);
	      switch (c) {
	      case ('\n'):
	        outputString = outputString + "<BR>";
	        break; // line feed -> <BR>
	      case ('\r'):
	        break; // remove carriage return
	      case (' '):
	        if (replaceSpaces) {
	          outputString = outputString + "&nbsp;";
	        } else {
	          outputString = outputString + c;
	        }
	        break;
	      default:
	        outputString = outputString + c;
	        break;
	      }
	    }

	    return outputString;
	  }
	
	

}
