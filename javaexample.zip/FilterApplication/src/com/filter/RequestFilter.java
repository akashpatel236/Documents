package com.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class RequestFilter
 */
public class RequestFilter implements Filter {

    /**
     * Default constructor. 
     */
    public RequestFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		
		 HttpServletRequest req = (HttpServletRequest) request;
	       HttpServletResponse res = (HttpServletResponse) response;
	       
	       System.out.println(req.getParameterMap());
	 
	       System.out.println(req.getParameter("userName"));
	    		   
	      chain.doFilter(new XSSRequestWrapper((HttpServletRequest)request), response);
	    /*   
		res.setContentType("text/html");
		
		PrintWriter out = res.getWriter();
		
		System.out.println("Inside do Filter");
		System.out.println(" Context : "+request.getServletContext()+""+request.getLocalAddr()+" "+req.getPathTranslated());
		
		// out.print("filter is invoked after"); 
		if(("akash".equals(req.getParameter("userName"))))
			res.sendRedirect("reloadPage.jsp");
		
		 
		chain.doFilter(request, response);
		
		// out.print("filter is invoked after");  
		*/
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		
		System.out.println("Inside init Filter");
		// TODO Auto-generated method stub
	}

}
