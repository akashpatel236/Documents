import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DiagnoseScreen {

	
	public static String getTokenWithDelimeter(String subpart,String delim)
	{
		
			String value="";
		
			StringTokenizer tkn = new StringTokenizer(subpart,delim);
		
			while(tkn.hasMoreTokens())
				value=tkn.nextToken();
			
			return value;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String result = " === Policercheck 14-03-2018 13:08:48 ==="+"\n"
				+"Gebruikte commando's :"+"\n"
				+"port show port 1"+"\n"
				+"Rx              :"+"\n"
				+"CRC Error Frames:                    0, Alignments Err :                    0,"+"\n"
				+"Bytes Received  :            186373423, Unicast Frames :              2006150,"+"\n"
				+"CRC Error Frames:                    0, Alignments Err :                    0,"+"\n"
				+"|UnderSize Frames:                    0, OverSize Frames:                    0,"+"\n"
				+"CRC Error Frames:                    0, Alignments Err :                    0,"+"\n"
				+"Tx              :"+"\n"
				+"Bytes Xmitted   :             11927199, Unicast Frames :                12327"+"\n"
				+"Gebruikte commando's"+"\n"
				+"UnderSize Frames:                    0, OverSize Frames:                    0,"+"\n"
				+"Broadcast Frames:                16388, M-cast Frames  :                    0,"+"\n"
				+"Lost Frames     :                    0, Collided Frames:                    0,"+"\n"
				+"Error Frames    :                    0"+"\n"
				+"Rx              :"+"\n"
				+"Bytes Received  :            186373509, Unicast Frames :              2006151,"+"\n"
				+"UnderSize Frames:                    0, OverSize Frames:                    0,,"+"\n"
				+"CRC Error Frames:                    0, Alignments Err :                    0,"+"\n"
				+"|UnderSize Frames:                    0, OverSize Frames:                    0,"+"\n"
				+"CRC Error Frames:                    0, Alignments Err :                    0,"+"\n"
				+"Tx          :"+"\n"
				+"Bytes Xmitted   :             11927199, Unicast Frames :                12327"+"\n"
				+"Gebruikte commando's"+"\n"
				+"UnderSize Frames:                    0, OverSize Frames:                    0,"+"\n"
				+"Broadcast Frames:                16388, M-cast Frames  :                    0,"+"\n"
				+"Lost Frames     :                    0, Collided Frames:                    0,"+"\n"
				+"Error Frames    :                    0"+"\n"
				+"Error Frames    :                    0"+"\n";
				
		
		
		
			if(result !=null && result.contains("Error Frames"))
					{
					
						System.out.println("Processing result..."+result);
						
						StringTokenizer token = new StringTokenizer(result,"\n");
						
						String regulareExpression="^Error Frames";
						Pattern pattern=Pattern.compile(regulareExpression);
						
						Matcher match = null;
						String subcopy[]=new String[2];
						String valueHolder = null;
						int i = 0;
								
								while(token.hasMoreTokens())
								{
									valueHolder=token.nextToken();
									match = pattern.matcher(valueHolder);
									
									if(match.find())
									{
											if(i<2)
												subcopy[i++]=valueHolder;
									}
								}	
						
								System.out.println(subcopy[0]+"  "+subcopy[1]);
								
								String ErrorValue1=getTokenWithDelimeter(subcopy[0],":").trim();
								String ErrorValue2=getTokenWithDelimeter(subcopy[1],":");
								
								if(ErrorValue1.matches("\\d+"))
										{
												System.out.println(Integer.parseInt(ErrorValue1));
										}
								
								System.out.println("Error Values "+ErrorValue1.trim()+ "  "+ErrorValue2.trim());
								
							System.out.println(result.length());
							
					}
			else
				System.out.println(" Response is not proper.");
			
			

	}


	
}





