
import java.util.ArrayList;

import java.io.*;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.naming.ldap.*;


import javax.naming.directory.*;
import javax.naming.*;

public class LDAPConnection {
	
	

		  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Hashtable<String, String> environment = new Hashtable<String, String>();
		
		environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        environment.put(Context.PROVIDER_URL, "ldap://sz0437.telecom.ptt.nl:389/o=kpn.com");
        environment.put(Context.SECURITY_AUTHENTICATION, "simple");
        environment.put(Context.SECURITY_PRINCIPAL, "cn=directory manager");
        environment.put(Context.SECURITY_CREDENTIALS, "admin001");
        
        try 
        {
            DirContext context = new InitialDirContext(environment);
            
            System.out.println("Connected..");
            
            System.out.println(context.getEnvironment());

            
            String[] attributeFilter = {"uid"};
            
            
            
            SearchControls sc = new SearchControls();
            
    
            sc.setReturningAttributes(attributeFilter);
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
            
            NamingEnumeration<SearchResult> results = context.search("ou=Telco","(objectclass=*)", sc);
            
            int count=0;
            
            while (results.hasMore()) {
            	
         
                SearchResult sr = results.next();
                
                Attributes attrs = sr.getAttributes();

                	//System.out.println(attrs);
                	
                Attribute attr = attrs.get("uid");

                if(attr != null )
                	//System.out.println(attr);
               	
               count++; 
                
            }
            
            System.out.println("Records are :"+count);
            
            Attributes attrs = context.getAttributes("cn=Bitstream,ou=Telco");
            List<String> l = new ArrayList<String>();
            for (NamingEnumeration ae = attrs.getAll(); ae.hasMore();) {
            	
                Attribute attr = (Attribute) ae.next();
                l.add(attr.getID()); 
            }
            
            System.out.println(l);
            
         /* for(String id:l)
          {
        	  
        	  System.out.println(id);
          }*/
            
    
            
            String csvFile = "C:/Users/patel512/test.csv";
            
            BufferedReader br= null;
            String line="";
            String splitby=",";
            String uid="";
            try
            {
            	
            	br=new BufferedReader(new FileReader(csvFile));
            	
            	while((line=br.readLine())!=null)
            	{
            		
            		//System.out.println(line);
            		 uid=line;
            	}
            	
            }
            catch(Exception e)
            {
            	System.out.println("File not Found.");
            	
            }
            
            
            System.out.println("Finding telco: ");
            
            
            
            String filter = "(&(objectclass=tietelcouser)(uid=" + uid + "))";
            
            
            results = context.search("ou=Telco", filter, sc);
            
            // Get Telco 
            String telcoName="";
            
            while (results.hasMore()) {

                SearchResult sr = results.next();
                
                System.out.println(sr.getName());
                
                String arr[]=sr.getName().split(",");
                
                 telcoName=arr[1].replaceAll("cn=","");
                
                System.out.println(telcoName);
                
            }
            
            
            String dn = "uid=" + uid + ",cn=" + telcoName + ",ou=Telco";
            
            
            System.out.println(dn);
        
        
            context.close();
          
            
            
            
        } 
        catch (AuthenticationNotSupportedException exception) 
        {
            System.out.println("The authentication is not supported by the server");
        }

        catch (AuthenticationException exception)
        {
            System.out.println("Incorrect password or username");
        }

        catch (NamingException exception)
        {
            System.out.println("Error when trying to create the context");
        }
		
			
	}

}
