package com.test.domain;

public class Person {
	
	
	private String firstname=null;
	private String lastname=null;

	
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return this.firstname+" "+this.lastname;
		}


		public String getFirstname() {
			return firstname;
		}


		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}


		public String getLastname() {
			return lastname;
		}


		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		
}
