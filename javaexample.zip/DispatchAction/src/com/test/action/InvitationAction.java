package com.test.action;

import javax.servlet.http.HttpServletRequest;


import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.test.form.InvitationForm;

import com.test.domain.*;

public class InvitationAction extends DispatchAction {
	
	
	public ActionForward add(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		
		
		InvitationForm iform = (InvitationForm) form;
		Person newperson = new Person();
		
		
		newperson.setFirstname(iform.getFirstName());
		newperson.setLastname(iform.getLastName());
		
		 iform.getPersonMap().put(iform.getKey(),newperson);
		
		 iform.reset(mapping, request);

		 return mapping.findForward("success");
				
	}
	
	
	 public ActionForward delete(ActionMapping mapping, ActionForm form,
			    HttpServletRequest request, HttpServletResponse response){
			        InvitationForm invForm = (InvitationForm)form;
			        invForm.getPersonMap().remove(invForm.getKey());
			        return mapping.findForward("success");
			    }

			    public ActionForward edit(ActionMapping mapping, ActionForm form,
			    HttpServletRequest request, HttpServletResponse response){
			        InvitationForm invForm = (InvitationForm)form;
			        Person person = invForm.getPersonMap().get(invForm.getKey());
			        invForm.setFirstName(person.getFirstname());
			        invForm.setLastName(person.getLastname());
			        return mapping.findForward("success");

			    }
			    
}
