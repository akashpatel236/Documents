package com.test.form;
import java.util.Date;

import com.test.domain.*;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class InvitationForm extends ActionForm {
	
	
	private static final long serialVersionUID = -4698158775973183265L;

	
    private Person currentPerson = new Person();
   
    private Map<Long,Person> personMap = new HashMap<Long,Person>();
    
    private long personId = new Date().getTime();

    public Map<Long, Person> getPersonMap() {
        return personMap;
    }

    public void setPersonMap(Map<Long, Person> personList) {
        this.personMap = personList;
    }

    public String getFirstName() {
        return currentPerson.getFirstname();
    }

    public void setFirstName(String firstName) {
        this.currentPerson.setFirstname(firstName);
    }

    public String getLastName() {
        return currentPerson.getLastname();
    }

    public void setLastName(String lastName) {
        this.currentPerson.setLastname(lastName);
    }

    public long getKey() {
        return personId;
    }

    public void setKey(long personId) {
        this.personId = personId;
    }
    
	
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
	
			this.currentPerson.setFirstname(null);
			this.currentPerson.setLastname(null);
			this.personId = new Date().getTime();
			super.reset(mapping, request);
	}
    
    
  

}
