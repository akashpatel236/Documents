
public class Processor {
	
	
	public static void main(String[] args) {
		
	
	String result = "=== Uni Chk 14-03-2018 13:09:21 ==="+"\n"
			+"Gebruikte commando's :"+"\n"
			+"port show port 1"+"\n"
			+"Field                                    Admin      Oper     "+"\n"
			+"============================================================"+"\n"
			+"Auto Negotiation                         Disabled   Disabled "+"\n"
			+"Flow Control                             off        off      "+"\n"
			+"Speed                                    100 Mbps   100 Mbps "+"\n"
			+"Link State                                 Disabled   Enabled  "+"\n"
			+"Description                              To_nl-undefined-uep-E6149866"+"\n"
			+"Type                                     FastEthernet       "+"\n"
			+"Spanning Tree State                      Forwarding         "+"\n"
			+"MAC Address                              00:03:18:d8:1a:82  "+"\n"
			+"State Group Link State                   empty              "+"\n";


		System.out.println(result);
		System.out.println("======================");	
				boolean check1=result.contains("Link State"); 
				boolean check2=result.contains("Description"); 
				
				if(check1 && check2)
				{
					String subpart=result.substring(result.indexOf("Link"),result.indexOf("Desc"));
					System.out.println(result.substring(result.indexOf("Link"),result.indexOf("Desc")));
					
					//System.err.println(subpart.length());
					
					boolean check3=subpart.contains("Enabled");
					
					if(check3)
						if(subpart.indexOf("Enabled")==subpart.lastIndexOf("Enabled"))
							if(subpart.indexOf("Enabled")<subpart.indexOf("Disabled"))
								System.out.println("Admin is enabled and Operation is disabled");
							else
								System.out.println("Admin is disabled and Operation is enabled");
						else
						System.out.println("Admin is enabled and Operation is Enabled");
					else
						System.out.println("Both are disabled.");
		}
	 
	//System.out.println();
	 
	 
	}
}

