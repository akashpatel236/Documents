import java.util.StringTokenizer;

public class Processor {
	
	
	public static void main(String[] args) {
		
	
		String result = " === Policercheck 14-03-2018 13:08:48 ==="+"\n"
				+"Gebruikte commando's :"+"\n"
				+"port show port 1"+"\n"
				+"+-------------------+"+"\n"
				+"  |     Bandwidth     |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"| Port (Dest)| Service ID| Service Name | PRI |   CIR   |   PIR   |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"|    agg1    |    128    |  VPN_83257   |  0  |    0    | 101056  |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"Gebruikte commando's"+"\n"
				+"flow service-mapping show statistics src-port 1"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| Network        | Cos      | Dropped Bytes | Dropped Bytes | Dropped Bytes |"+"\n"
				+"|                |          |    meting 1   |    meting 2   |   in 10 sec   |"+"\n"
				+"+----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| vs   VPN_83257 |          |   842682636   |   842682636   |       0       |"+"\n"
				+"+----------------+----------+---------------+---------------+---------------+"+"\n"
				+"Gebruikte commando's"+"\n"
				+"port show port 1 statistics"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"|                |          |    meting 1   |    meting 2   |   in 10 sec   |"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| RxBytes                | 8269309078678 | 8269309281197 |      202519      |"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| TxBytes                | 4010703075940 | 4010706082857 |     3006917      |"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n";
			
		
		String result2 = " === Policercheck 14-03-2018 13:08:48 ==="+"\n"
				+"Gebruikte commando's :"+"\n"
				+"port show port 1"+"\n"
				+"+-------------------+"+"\n"
				+"  |     Bandwidth     |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"| Port (Dest)| Service ID| Service Name | PRI |   CIR   |   PIR   |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"|    agg1    |    128    |  VPN_83257   |  0  |    0    | 101056  |"+"\n"
				+"+------------+-----------+--------------+-----+---------+---------+"+"\n"
				+"Gebruikte commando's"+"\n"
				+"flow service-mapping show statistics src-port 1"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| Network        | Cos      | Dropped Bytes | Dropped Bytes | Dropped Bytes |"+"\n"
				+"|                |          |    meting 1   |    meting 2   |   in 10 sec   |"+"\n"
				+"+----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| vs   VPN_83257 |          |   842682636   |   842682636   |       0       |"+"\n"
				+"+----------------+----------+---------------+---------------+---------------+"+"\n"
				+"Gebruikte commando's"+"\n"
				+"port show port 1 statistics"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| Total octets passed    |  4195207567   |  4195292269   |      84702       |"+"\n"
				+"----------------+----------+---------------+---------------+---------------+"+"\n"
				+"| Total octets discarded |   21181805    |   21181805    |        0         |"+"\n"
				+"----------------+----------+---------------+---------------+---------------+";
				
System.out.println(result);


System.out.println("========================");

System.out.println(result2);

boolean check4=result2.contains("passed"); 
boolean check5=result2.contains("discarded"); 
boolean check6=result2.contains(""); 
if(check4 && check5)
	
{
	String subpart=result2.substring(result2.indexOf("passed"),result2.lastIndexOf("Total"));
		
			subpart=subpartfunction(subpart);
			System.out.println("part 1 value ="+subpart);
			StringTokenizer st = new StringTokenizer(subpart," ");
			while(st.hasMoreTokens())
				subpart=st.nextToken();
			
			System.out.println(subpart);
			
			subpart = result2.substring(result2.indexOf("discarded"),result2.length());
			subpart=subpartfunction(subpart);
			System.out.println("part 2 value ="+subpart);
			
			 st = new StringTokenizer(subpart," ");
			while(st.hasMoreTokens())
				subpart=st.nextToken();
			
			System.out.println(subpart);
}

//System.out.println(r.length());

CharSequence chr="";

boolean check1=result.contains("sec"); 
boolean check2=result.contains("RxBytes"); 
boolean check3=result.contains("TxBytes"); 


		if(check1 && check2 && check3)
		{
				String subpart=result.substring(result.indexOf("sec"),result.lastIndexOf("Gebru"));
				String value="";
				System.out.println(subpart);
				
				subpart=subpartfunction(subpart);
				
				StringTokenizer tkn = new StringTokenizer(subpart," ");
				while(tkn.hasMoreTokens())
				{
					value=tkn.nextToken();
					System.out.println("values is"+value);
				}
				System.out.println("Tx value:"+value);
				System.out.println("For transaction and receving bytes");
				
				subpart = result.substring(result.indexOf("RxBytes"),result.indexOf("TxBytes"));
				
				System.out.println(subpart);
				subpart=subpartfunction(subpart);
				System.out.println(subpart);
				
				tkn = new StringTokenizer(subpart," ");
				while(tkn.hasMoreTokens())
					value=tkn.nextToken();
				System.out.println("Tx value:"+value);
				subpart = result.substring(result.indexOf("TxBytes"),result.length());
				
				System.out.println(subpart);
				subpart=subpartfunction(subpart);
				System.out.println(subpart);
				
				tkn = new StringTokenizer(subpart," ");
				while(tkn.hasMoreTokens())
					value=tkn.nextToken();
				
				System.out.println("Tx value:"+value);
		}
		 
		//System.out.println();
		 
		 
}

		public static String subpartfunction(String subpart)
		{
		
		subpart=subpart.replace("-","");
		subpart=subpart.replace("+","");
		subpart=subpart.replace("|","");
		
		subpart=subpart.trim();
		return subpart;
		}


}

