import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;

import javax.xml.bind.DatatypeConverter;

public class TestString {
	
	
	public static Map<String,String> callit(){
		
		HashMap<String,String> test1 = new HashMap<String,String>();
		
			test1.put("akash", "patel");
		
		return test1;
	}
	
	public static void main(String[] args) {
		
		
		System.out.println("Processing Calender.......");
		
		String initialDate="2019-01-23";

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
     	String planneddate=df.format(new Date());
     	
     	//String initialPlanDate_in_date="2019-04-24 24:00:00";
     			try{/*
     				Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(initialDate);
     				String formattedInitialPlanDate1=df.format(date1);
     				System.out.println(formattedInitialPlanDate1);*/
     				
     				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
     		        Date initialDate1 = sdf.parse(initialDate);
     		        Date planneddate2 = sdf.parse("2019-02-23");
     		       System.out.println(initialDate1+" "+planneddate2);
     		       
     		      if (planneddate2.compareTo(initialDate1) > 0) {
     		            System.out.println("planneddate2 is after initialDate1");
     		        } else if (planneddate2.compareTo(initialDate1) < 0) {
     		            System.out.println("planneddate2 is before initialDate1");
     		        } else if (planneddate2.compareTo(initialDate1) == 0) {
     		            System.out.println("Date1 is equal to Date2");
     		        } else {
     		            System.out.println("How to get here?");
     		        }
     		        
     			}catch(Exception e){}
		 
     
		 
		String valueofport = "Optical-SM";
		
		StringTokenizer st = new StringTokenizer(valueofport,"-");
		System.out.println(st.nextToken());
		System.out.println(st.nextToken());
		List<String> valuecheck = new ArrayList<String>();
		valuecheck.add("akash");
		valuecheck.add("akash1");
		valuecheck.add("akash2");
		
		System.out.println("String"+valuecheck.toString().substring(1,valuecheck.toString().length()-1));
		String previousCOSID = null;
		
		if(!(previousCOSID!=null))
			System.out.println("value is null for COS");
		
		Map<String,String> test1 = callit();
		System.out.println(test1 +" "+test1.get("akash"));
		
		//Generate Password 
	    String Capital_chars = "ABCD19EF$GH78IJKLMNOPQ#RS5T%UVWXYZ"; 
		String Small_chars = "abc%def234ghijkl#m6nopqrst$uvwxyz"; 
		String symbols = "@#$%";
	    
		String values = Capital_chars + Small_chars + symbols;
		Random random = new Random();
		String pwd="";
		for(int i=0;i<9;i++){
			pwd=pwd+values.charAt(random.nextInt(values.length()));
		}
		System.out.println(pwd);
		 
		
		HashMap<String, Boolean> services = new HashMap<String, Boolean>();
		 
			services.put("weas",true);
		services.put("weasserv",false);
		services.put("mdfserv",false);
		services.put("mdftt",true);
		services.put("wlrserv",true);
		services.put("wlrtt",true);
		services.put("cpeserv",true);
		services.put("cpstt",false);
		services.put("rasserv",true);
		services.put("emthserv",false);
		services.put("specialserv",false);
		services.put("oiserv",false);
		services.put("solbeeher",false);
		services.put("solbill",false);
		services.put("solrep",true);
		
		System.out.println(services.get("weas"));
		System.out.println(services.get("cpstt"));
		
		for (Map.Entry<String, Boolean> entry  : services.entrySet()) {
			
			if(entry.getKey().equals("emthserv"))
				if(entry.getValue().equals(true))
					System.out.println(entry.getKey()+"yes");
				else
					System.out.println(entry.getKey()+"no");
			
			if(entry.getKey().equals("solrep"))
				if(entry.getValue().equals(true))
					System.out.println(entry.getKey()+"yes");
				else
					System.out.println(entry.getKey()+"no");
	
			if(entry.getKey().equals("solbill"))
				if(entry.getValue().equals(true))
					System.out.println(entry.getKey()+"yes");
				else
					System.out.println(entry.getKey()+"no");
			
		}
		
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat1.format(date)); 
	
		File fp = new File("test1.txt");
		System.out.println("Absolute path :"+fp.getAbsolutePath());
		FileWriter fw = null;
		try {
			 fw = new FileWriter(fp,true);
			 fw.write("Hi This is Akash.");
			 fw.write("\n");
			 fw.append("asdksds");
			 
				fw.flush();
				//fw.close();
				
				/*
				  flush() writes the content of the buffer to the destination and makes the buffer empty for further data to store but it does not closes the stream permanently. That means you can still write some more data to the stream.

But close() closes the stream permanently. If you want to write some data further, then you have to reopen the stream again and append the data with the existing ones.
				 */
			 
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		
		
		String discardedOctets="0ffd";
		try{
			
		if(Integer.parseInt(discardedOctets)>0)
		{
			
			System.out.println(discardedOctets);
		}
	}catch(Exception e)
	{
			System.out.println("HEre");
	}
		HashMap<String, Boolean> servicess = new HashMap<String,Boolean>();
	 	
		servicess.put("wead", true);
		servicess.put("emtn", false);
		servicess.put("emtnsd", false);
		servicess.put("special", true);
		
		String option="emtnsd";
		
	 	if(!servicess.isEmpty())
	 		if(servicess.containsKey(option))
	 			if(servicess.get(option).equals(true)){
	 					System.out.println(option+"set to "+false);
	 			}
		
		List<String> datas = new ArrayList<String>();
		
		if(datas!=null && !datas.isEmpty())
			System.out.println("puchi gayo la");
		datas.add("ras");
		System.out.println(datas.toString());
		datas=null;
		if(datas==null)
			System.out.println("here");
		Map<String,String> details = new HashMap<String, String>();
		
		details.put("name", "akash");
		details.put("telco", "bsa");
		details.put("userid", "asd111");
		
		String telcoName="'";
		  for (String key : details.keySet()) {
	          if ("telco".equals(key)) {
	            telcoName = details.get(key);
	          }
	        }
		
		  System.out.println("Map example "+details.toString()+telcoName);
		String value="Optical-MM";
		
		StringTokenizer token = new StringTokenizer(value,"-");
		String v1="";
		String v2="";
		if(token.hasMoreTokens())
		v1=token.nextToken();
		if(token.hasMoreTokens())
			v2=token.nextToken();
		
		System.out.println(v1+" "+v2);
		
		
		Collection<String> sortDD;
		
		sortDD = new ArrayList<String>();
		
		sortDD.add("akash");
		sortDD.add("zebra");
		sortDD.add("harsh");
		sortDD.add("yash");
		

		System.out.println(sortDD);
		
		 ArrayList<arrayListDemo> countryList = new ArrayList<arrayListDemo>();
		 
		 countryList.add(new arrayListDemo("1", "USA"));
	        countryList.add(new arrayListDemo("2", "Canada"));
	        countryList.add(new arrayListDemo("3", "Mexico"));
		
	        
	        arraylistForm ob = new arraylistForm();
	        
	        ob.setCountryList(countryList);
	        
	        System.out.println(countryList.get(0).getCountryName() + " "+countryList.size());
	        
	        ArrayList<String> listArray=new ArrayList<>();
	        
	        listArray.add("sdfklsdjfsildf");
	        listArray.add("sdfklsdjfsildf");
	        listArray.add("sdfklsdjfsildf");listArray.add("sdfklsdjfsildf");listArray.add("sdfklsdjfsildf");listArray.add("sdfklsdjfsildf");
	        System.out.println(listArray.size()-1);
	        ListIterator<String> itr= listArray.listIterator(listArray.size()-3);
	        
	        while(itr.hasNext())
	        	System.out.println(itr.next());
	        
	        
		//Normal Date
		 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		  Calendar cal = Calendar.getInstance();
		  System.out.println("normal date Format: "+dateFormat.format(cal.getTime()));
		  
		  // Dat in CET
		  
		  cal=Calendar.getInstance();
			String stringDate=cal.getTime().toString();
			SimpleDateFormat sdf = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
		    Date parsedDate;
			try {
				parsedDate = sdf.parse(stringDate);
			    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			    String pd=sdf1.format(parsedDate);
			    Date parsedDate1 = sdf1.parse(pd);
			   System.out.println("CET date :  "+parsedDate1.toGMTString());
			   
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println("==========================");
		MessageDigest md=null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      byte[] digested = md.digest("test001".getBytes());
	      String encodedPassword = DatatypeConverter.printBase64Binary(digested);
	      System.out.println(encodedPassword);
	      
	      
	String result = "iojsdfgs|o9df^u7389rurnw$8er7|h9weu"+'\n'+"Akash Patel"+"\n"
			+"1/1 enabked up  asksdfjdfijdfofj"
			+"sdfkjsdfijdfijdf"+"\n"+
			"sfldjfjdfgijfgiofjgoij"
			+"1/2 sdfkjsdfijdfijdf"+"\n"+
			"sfldjfjdfgijfgiofjgoij"
			+"sdfkjsdfijdfijdf Up"+"\n"+
			"sfldjfjdfgijfgiofjgoij"
			+"1/1 dsfkjdfkg up sfldjfkdf dfkugndfkg"+
			"1/2 esdfkjdngd kdfgnkfjgkfg kjjdgfjg"
			+"1/11 dsfkjdfkg up sfldjfkdf dfkugndfkg"+
			"1/12 esdfkjdngd kdfgnkfjgkfg kjjdgfjg";  //A very large String atleast 50kb
	
	StringBuilder r=new StringBuilder(result);
	
	System.out.println("To upper case "+result.toUpperCase());
	
	String lines[] = result.split("\\r?\\n");
	
	//for(int i=0;i<lines.length;i++)
		//System.out.println(i+ "  "+lines[i]);
	System.out.println(lines[2]);
	
	String operation="Operational Status is up/active,"+"\n"
+"Customerport X is physically up"+"\n"
+"Please check Policer Chk";
	
	operation=operation.replace("up/active","active");
	
	System.out.println(operation);
	
	String test="";
	
	if(test==null)
		System.out.println("Test String is null");

	String portcheck="port X is down \n Port x is up."+"\n"+"dfjkhdfuhdfudhfhfdgukhdfgjh";
	
	int newport=0;
	
	boolean check3=(result.contains("up") || result.contains("UP") || result.contains("Up"));
	
	if(check3)
			System.out.println("hai bhai hai");
	
	portcheck=portcheck.replace("X",Integer.toString(1));
	
		System.out.println(portcheck);
		
		String supportedTest="deviceports:";
		supportedTest=supportedTest+"PortStatus:";
		supportedTest=supportedTest+"ErrorCheck:";
		
		if(supportedTest.contains("deviceports"))
			System.out.println("dp supported");
		if(supportedTest.contains("PortStatus"))
				System.out.println("ps supported");
		
	//System.out.println(r);
	
	//System.out.println(r.length());
	int portid=1;
	int next=portid+2;
	System.out.println(r.lastIndexOf("1/1 "));
	System.out.println(r.lastIndexOf("1/3 "));
	
	System.out.println(r.indexOf("1/1 "));
	System.out.println(r.indexOf("1/2 "));		
			
			CharSequence chr="";
			if(result.contains("1/"+next+" "))
				chr=r.subSequence(r.lastIndexOf("1/"+portid+" "),r.lastIndexOf("1/"+next+" "));
				//System.out.println(r.subSequence(r.indexOf("1/1 "),r.indexOf("1/2 ")));
			else
				chr=r.subSequence(r.lastIndexOf("1/"+portid+" "),r.lastIndexOf("1/"+portid+" ")+50);
			
			System.out.println(r.subSequence(r.lastIndexOf("1/"+portid+" "),r.lastIndexOf("1/"+portid+" ")+50));
			
			if(chr.toString().contains("up") ||  chr.toString().contains("Up") || chr.toString().contains("UP"))
			{
				
				System.out.println("Port is up.");
			}
	}

}
