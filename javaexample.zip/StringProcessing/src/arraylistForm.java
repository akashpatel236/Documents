import java.util.ArrayList;

public class arraylistForm {

	
	private ArrayList<arrayListDemo> countryList = new ArrayList<arrayListDemo> ();
	
	
	public ArrayList getCountryList() {
        return countryList;
    }

    /**
     * @param countryList the countryList to set
     */
    public void setCountryList(ArrayList countryList) {
        this.countryList = countryList;
    }
}
