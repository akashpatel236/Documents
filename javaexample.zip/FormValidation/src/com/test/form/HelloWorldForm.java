package com.test.form;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.taglib.html.ErrorsTag;

public class HelloWorldForm extends ActionForm {

	private static final long serialVersionUID = -473562596852452021L;
	
	private String username=null;
	private String password=null;
	private String pincode=null;
	private String country=null;
	
	private boolean veg=false;
	private boolean nonveg=false;
	
	
	
	@Override
	public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
	{
		System.out.println("Reset form");
		this.username=null;
		this.password=null;
		this.pincode=null;
		this.country=null;
		this.veg=false;
		this.nonveg=false;
	}
	
	
	@Override
	public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request) 
	
	{
		ActionErrors err = new ActionErrors();
		
		/*if ( this.username == null || this.username.trim().equals(""))
			
			err.add("username",new ActionMessage("err.required","name"));
		*/
		
		
		
		return err; 
	}
	
	




	public boolean isVeg() {
		return veg;
	}


	public void setVeg(boolean veg) {
		this.veg = veg;
	}


	public boolean isNonveg() {
		return nonveg;
	}


	public void setNonveg(boolean nonveg) {
		this.nonveg = nonveg;
	}


	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
